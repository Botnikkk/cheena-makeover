import React, { useState, useEffect, useMemo } from "react";
import Carousel from "react-bootstrap/Carousel";
import { motion } from "framer-motion";

import useIsMobile from "../hooks/useIsMobile";
import { flip, rise, pick, PRESERVE_3D } from "../lib/animations";
import { fetchGalleryImages, urlFor } from "../lib/sanityClient";
import LeftArrow from "../assets/icons/left-arrow.svg";
import RightArrow from "../assets/icons/right-arrow.svg";

const desktopVariant = flip();
const mobileVariant = rise();

// Lower threshold on phones, where the carousels are tall relative to the screen.
const VIEWPORT_DESKTOP = { once: true, amount: 0.3 };
const VIEWPORT_MOBILE = { once: true, amount: 0.1 };

const PERSPECTIVE = { perspective: "1200px" };

const prevIcon = <img className="GalleryArrow" src={LeftArrow} alt="left" />;
const nextIcon = <img className="GalleryArrow" src={RightArrow} alt="right" />;

function GalleryCarousel({ label, items, variants, isMobile }) {
  // Build the image URLs once per data set instead of on every render.
  const slides = useMemo(
    () =>
      items.map((item, index) => ({
        id: item._id || index,
        src: urlFor(item.image).width(800).auto("format").url(),
        alt: item.title || `${label} ${index + 1}`,
      })),
    [items, label]
  );

  return (
    <motion.div
      className="CarouselContainer"
      initial="hidden"
      whileInView="visible"
      viewport={isMobile ? VIEWPORT_MOBILE : VIEWPORT_DESKTOP}
      variants={variants}
      style={isMobile ? undefined : PRESERVE_3D}
    >
      <Carousel fade prevIcon={prevIcon} nextIcon={nextIcon}>
        {slides.map((slide) => (
          <Carousel.Item key={slide.id}>
            <img
              className="GalleryImage d-block w-100"
              src={slide.src}
              alt={slide.alt}
            />
            <Carousel.Caption>
              <h3>{label}</h3>
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>
    </motion.div>
  );
}

export default function Gallery() {
  const isMobile = useIsMobile();
  const [images, setImages] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetchGalleryImages()
      .then((data) => {
        if (!cancelled) setImages(data);
      })
      .catch((error) => {
        console.error(error);
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Nothing to show if the request failed.
  if (failed) return null;

  const variants = pick(isMobile, desktopVariant, mobileVariant);

  return (
    <div id="gallery" className="section Gallery">
      {/* Render the section shell while loading so the page doesn't jump (and
          the "GALLERY" nav link has a target) once the images arrive. */}
      {images && (
        <div className="GalleryMainContainer" style={isMobile ? undefined : PERSPECTIVE}>
          <GalleryCarousel label="Bridal" items={images.Bridal} variants={variants} isMobile={isMobile} />
          <GalleryCarousel label="Party" items={images.Party} variants={variants} isMobile={isMobile} />
        </div>
      )}
    </div>
  );
}
