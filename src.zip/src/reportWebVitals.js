// Works with both the old (getCLS...) and new (onCLS...) web-vitals APIs.
const METRICS = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

const reportWebVitals = (onPerfEntry) => {
  if (typeof onPerfEntry !== "function") return;

  import("web-vitals").then((vitals) => {
    METRICS.forEach((name) => {
      const report = vitals[`on${name}`] || vitals[`get${name}`];
      if (report) report(onPerfEntry);
    });
  });
};

export default reportWebVitals;
