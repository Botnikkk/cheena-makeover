import React, { Suspense, lazy } from "react";

import Home from "../sections/Home";
import About from "../sections/About";
import Services from "../sections/Services";

// Gallery pulls in react-bootstrap's Carousel and the Sanity client, so it's
// split out of the main bundle.
const Gallery = lazy(() => import("../sections/Gallery"));

// Holds the gallery's place while its chunk downloads, so the layout (and the
// "GALLERY" nav target) don't jump.
const galleryPlaceholder = <div id="gallery" className="section Gallery" />;

export default function HomePage() {
  return (
    <>
      <Home />
      <About />
      <Suspense fallback={galleryPlaceholder}>
        <Gallery />
      </Suspense>
      <Services />
    </>
  );
}
