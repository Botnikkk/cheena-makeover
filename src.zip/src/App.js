import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import { HashRouter as Router, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";

import Header from "./components/Header";
import HomePage from "./pages/HomePage";
import Bridal from "./pages/Bridal";
import BridalCocktail from "./pages/BridalCocktail";
import Cocktail from "./pages/Cocktail";
import Party from "./pages/Party";
import Booking from "./pages/Booking";

const scrollToTop = () => window.scrollTo({ top: 0, left: 0, behavior: "instant" });

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait" onExitComplete={scrollToTop}>
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<HomePage />} />
        <Route path="/bridal" element={<Bridal />} />
        <Route path="/bridalcocktail" element={<BridalCocktail />} />
        <Route path="/cocktail" element={<Cocktail />} />
        <Route path="/party" element={<Party />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  return (
    <Router>
      <Header />
      <AnimatedRoutes />
    </Router>
  );
}

export default App;
